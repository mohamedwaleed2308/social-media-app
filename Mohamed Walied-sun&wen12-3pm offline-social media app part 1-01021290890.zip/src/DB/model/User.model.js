import mongoose, { model, Schema } from "mongoose";

export const genderTypes={male:'male',female:'female'}
export const roleTypes={user:'user',admin:'admin'}
export const providerTypes={system:'system',google:'google'}

const userSchema=new Schema({
    userName:{
        type:String,
        required:true,
        minlength:2,
        maxlength:25,
        trim:true
    },
    email:{
        type:String,
        required:true,
        unique:true
    },
    otp:String,

    password:{
        type:String
    },
    forgetPasswordOtp:String,

    phone:String,
    DOB:Date,
    image:String,
    coverImage:[String],
    gender:{
        type:String,
        enum:Object.values(genderTypes),
        default:genderTypes.male
    },
    role:{
        type:String,
        enum:Object.values(roleTypes),
        default:roleTypes.user
    },
    provider:{
        type:String,
        enum:Object.values(providerTypes),
        default:providerTypes.system
    },
    confirmEmail:{
        type:Boolean,
        default:false
    },
    isdeleted:{
        type:Boolean,
        default:false
    },
    changeCredentialsTime:Date,
    otpTime:Date
},{timestamps:true})

export const userModel=mongoose.models.User || model('User', userSchema)
