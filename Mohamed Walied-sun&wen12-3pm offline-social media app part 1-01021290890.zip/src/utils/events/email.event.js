import {EventEmitter}from 'node:events'
import { nanoid,customAlphabet } from 'nanoid';
import { verificationEmailTemplate } from '../email/template/email.template.js';
import { userModel } from '../../DB/model/User.model.js';
import { generateHash } from '../security/hash.js';
import { sendEmail } from '../email/send.email.js';
export const emailEvent=new EventEmitter()

emailEvent.on('confirmEmail',async(data)=>{
    const {email}=data;
    const otp= customAlphabet('123456789',4)();
    const html=verificationEmailTemplate({code:otp})
    const otpHash= generateHash({plainText:`${otp}`})
    await userModel.updateOne({email},{otp:otpHash})
    await sendEmail({to:email,html,subject:'confirm-Email'})

})
emailEvent.on('forgetPassword',async(data)=>{
    const {email}=data;
    const otp= customAlphabet('123456789',4)();
    const html=verificationEmailTemplate({code:otp})
    const forgetPasswordOtp= generateHash({plainText:`${otp}`})
    await userModel.updateOne({email},{forgetPasswordOtp})
    await sendEmail({to:email,html,subject:'forget-password'})

})