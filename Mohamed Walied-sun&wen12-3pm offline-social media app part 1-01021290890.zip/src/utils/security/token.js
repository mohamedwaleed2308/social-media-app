import jwt from "jsonwebtoken";

export const generateToken=({payload={},signature,expiresIn=1800}={})=>{
    const token=jwt.sign(payload,signature,{expiresIn:parseInt(expiresIn)})
    return token;
}


export const verifyToken=({token,signature}={})=>{
    const decoded=jwt.verify(token,signature)
    return decoded;
}