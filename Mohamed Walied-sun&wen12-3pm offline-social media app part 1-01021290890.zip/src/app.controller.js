import DBConnection from "./DB/connction.js";
import authController from './module/auth/auth.controller.js'
import { globalErrorHandleing } from "./utils/response/error.response.js";
import cors from 'cors'

const Bootstrap = (app, express) => {
    app.use(cors())
    app.use(express.json());// convert buffer into data
    // app-routing
    app.get('/', (req, res) => res.send('Hello World!'))
    // sub-routing
    app.use('/auth',authController)
    // not-found 
    app.all('*',(req,res,next)=>{
        return res.status(404).json({message:'Not-Found'})
    });

    app.use(globalErrorHandleing)
    // DB-Connection
    DBConnection()
}

export default Bootstrap;