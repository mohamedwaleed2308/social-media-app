import * as mutationResolver from "./post/services/mutation.resolver.js";
import * as queryResolver from "./post/services/query.resolver.js";
import * as userResolver from "./user/services/user.resolve.js";
import { GraphQLObjectType, GraphQLSchema } from 'graphql'


export const schemaPosts = new GraphQLSchema({
    query:new GraphQLObjectType({
        name:'queryPosts',
        description:'this query get posts',
        fields:{
            ...queryResolver,
            ...userResolver
        }
    }),
    mutation:new GraphQLObjectType({
        name:'mutation',
        fields:{
            ...mutationResolver
        }
    })

})
